package com.example.toad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToadApplicationTests {

	@Test
	void contextLoads() {
	}

}
