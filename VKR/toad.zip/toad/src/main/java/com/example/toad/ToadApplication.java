package com.example.toad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToadApplication.class, args);
	}

}
